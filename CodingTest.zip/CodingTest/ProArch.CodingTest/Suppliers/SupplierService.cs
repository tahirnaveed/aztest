﻿namespace ProArch.CodingTest.Suppliers
{
    public class SupplierService
    {
        public Supplier GetById(int id)
        {
            return new Supplier();
        }
    }
}
